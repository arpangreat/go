package testing

type T struct{}

func (t *T) Helper() {}

type B struct{}

func (b *B) Helper() {}

type TB struct{}

func (tb *TB) Helper() {}
