package b

import "testing"

func BenchmarkAny(b *testing.B) {}
