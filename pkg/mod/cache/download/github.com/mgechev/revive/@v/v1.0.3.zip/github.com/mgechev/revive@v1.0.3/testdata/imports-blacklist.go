package fixtures

import (
	"crypto/md5"  //  MATCH /should not use the following blacklisted import: "crypto/md5"/
	"crypto/sha1" // MATCH /should not use the following blacklisted import: "crypto/sha1"/
	"strings"
)
