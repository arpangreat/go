package foo

import "github.com/mgechev/dots/fixtures/pkg/foo/bar"

func foo() bar.Bar {
	var b bar.Bar
	return b
}
