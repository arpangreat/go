package bar

type Bar struct{}
