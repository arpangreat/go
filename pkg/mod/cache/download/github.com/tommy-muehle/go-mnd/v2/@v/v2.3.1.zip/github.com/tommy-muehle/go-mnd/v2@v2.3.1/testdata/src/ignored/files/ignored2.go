package files

import (
	"net/http"
)

// ignored file

func example1() {
	http.StatusText(200)
}
