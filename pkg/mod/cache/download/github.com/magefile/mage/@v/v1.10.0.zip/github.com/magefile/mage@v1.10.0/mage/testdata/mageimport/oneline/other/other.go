package other

import "fmt"

func Build() {
	fmt.Println("build")
}
