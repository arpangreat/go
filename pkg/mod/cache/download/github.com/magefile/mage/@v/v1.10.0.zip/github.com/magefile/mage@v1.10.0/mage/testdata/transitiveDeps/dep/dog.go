package dep

import "fmt"

func Speak() {
	fmt.Println("woof")
}
