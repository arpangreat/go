+++
title = "{{ replace .TranslationBaseName "-" " " | title }}"
date = {{ .Date }}
type = "post"
author = "Nate Finch"
authorLink = "twitter.com/natethefinch"
draft = true
+++

