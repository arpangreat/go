# github.com/markbates/refresh Stands on the Shoulders of Giants

github.com/markbates/refresh does not try to reinvent the wheel! Instead, it uses the already great wheels developed by the Go community and puts them all together in the best way possible. Without these giants, this project would not be possible. Please make sure to check them out and thank them for all of their hard work.

Thank you to the following **GIANTS**:


* [github.com/fatih/color](https://godoc.org/github.com/fatih/color)

* [github.com/fsnotify/fsnotify](https://godoc.org/github.com/fsnotify/fsnotify)

* [github.com/gobuffalo/envy](https://godoc.org/github.com/gobuffalo/envy)

* [github.com/gobuffalo/events](https://godoc.org/github.com/gobuffalo/events)

* [github.com/gobuffalo/genny](https://godoc.org/github.com/gobuffalo/genny)

* [github.com/gobuffalo/packr/v2](https://godoc.org/github.com/gobuffalo/packr/v2)

* [github.com/markbates/grift](https://godoc.org/github.com/markbates/grift)

* [github.com/mattn/go-colorable](https://godoc.org/github.com/mattn/go-colorable)

* [github.com/mitchellh/go-homedir](https://godoc.org/github.com/mitchellh/go-homedir)

* [github.com/spf13/cobra](https://godoc.org/github.com/spf13/cobra)

* [gopkg.in/yaml.v2](https://godoc.org/gopkg.in/yaml.v2)
