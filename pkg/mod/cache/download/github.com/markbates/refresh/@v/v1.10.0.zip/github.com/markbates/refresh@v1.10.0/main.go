package main

import "github.com/markbates/refresh/cmd"

func main() {
	cmd.Execute()
}
