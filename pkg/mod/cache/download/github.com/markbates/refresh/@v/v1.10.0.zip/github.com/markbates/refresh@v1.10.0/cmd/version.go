package cmd

const Version = "1.4.0"
