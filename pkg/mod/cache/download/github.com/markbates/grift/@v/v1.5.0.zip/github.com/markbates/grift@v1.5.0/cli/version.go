package cli

const Version = "v1.5.0"
