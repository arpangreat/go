package oncer

// Version of oncer
const Version = "v1.0.0"
