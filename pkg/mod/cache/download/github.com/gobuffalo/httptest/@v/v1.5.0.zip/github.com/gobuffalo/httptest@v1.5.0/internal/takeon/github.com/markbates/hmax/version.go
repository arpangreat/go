package hmax

// Version of hmax
const Version = "v1.1.0"
