/*
Package genny is a _framework_ for writing modular generators, it however, doesn't actually generate anything. It just makes it easier for you to. :)
*/
package genny
