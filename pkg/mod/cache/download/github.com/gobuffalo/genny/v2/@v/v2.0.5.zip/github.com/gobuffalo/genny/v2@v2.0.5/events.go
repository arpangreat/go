package genny

/*
Events have been deprecated. Please manually trigger events if needed.
*/
const (
	EvtStarted     = "genny:runner:started"
	EvtFinished    = "genny:runner:finished"
	EvtFinishedErr = "genny:runner:finished:err"
	EvtStepPrefix  = "genny:step"
)
