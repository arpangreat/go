package gitgen

// Version of gitgen
const Version = "v0.0.1"
