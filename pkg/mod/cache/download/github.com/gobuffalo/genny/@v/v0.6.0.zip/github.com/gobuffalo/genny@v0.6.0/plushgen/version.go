package plushgen

// Version of plushgen
const Version = "v0.1.2"
