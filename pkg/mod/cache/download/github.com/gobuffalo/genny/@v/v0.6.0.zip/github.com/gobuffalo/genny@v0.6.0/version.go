package genny

var Version = ""
