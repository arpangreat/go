package gogen

// Version of gogen
const Version = "v0.2.0"
