package depgen

// Version of depgen
const Version = "v0.2.0"
