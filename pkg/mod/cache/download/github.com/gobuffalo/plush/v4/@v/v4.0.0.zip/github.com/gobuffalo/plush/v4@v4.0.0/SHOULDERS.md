# github.com/gobuffalo/plush Stands on the Shoulders of Giants

github.com/gobuffalo/plush does not try to reinvent the wheel! Instead, it uses the already great wheels developed by the Go community and puts them all together in the best way possible. Without these giants, this project would not be possible. Please make sure to check them out and thank them for all of their hard work.

Thank you to the following **GIANTS**:


* [github.com/fatih/structs](https://godoc.org/github.com/fatih/structs)

* [github.com/gobuffalo/github_flavored_markdown](https://godoc.org/github.com/gobuffalo/github_flavored_markdown)

* [github.com/gobuffalo/helpers](https://godoc.org/github.com/gobuffalo/helpers)

* [github.com/gobuffalo/packr/v2](https://godoc.org/github.com/gobuffalo/packr/v2)

* [github.com/gobuffalo/tags](https://godoc.org/github.com/gobuffalo/tags)

* [github.com/gobuffalo/uuid](https://godoc.org/github.com/gobuffalo/uuid)

* [github.com/gobuffalo/validate](https://godoc.org/github.com/gobuffalo/validate)

* [github.com/gofrs/uuid](https://godoc.org/github.com/gofrs/uuid)

* [github.com/golang/protobuf](https://godoc.org/github.com/golang/protobuf)

* [github.com/onsi/ginkgo](https://godoc.org/github.com/onsi/ginkgo)

* [github.com/onsi/gomega](https://godoc.org/github.com/onsi/gomega)

* [github.com/pkg/errors](https://godoc.org/github.com/pkg/errors)

* [github.com/serenize/snaker](https://godoc.org/github.com/serenize/snaker)

* [github.com/spf13/cobra](https://godoc.org/github.com/spf13/cobra)

* [github.com/stretchr/testify](https://godoc.org/github.com/stretchr/testify)

* [golang.org/x/sync](https://godoc.org/golang.org/x/sync)

* [golang.org/x/text](https://godoc.org/golang.org/x/text)
