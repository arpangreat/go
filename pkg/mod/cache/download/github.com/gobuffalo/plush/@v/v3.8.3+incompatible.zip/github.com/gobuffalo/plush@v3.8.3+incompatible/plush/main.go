package main

import "github.com/gobuffalo/plush/plush/cmd"

func main() {
	cmd.Execute()
}
