package github_flavored_markdown

const Version = "v1.1.0"
