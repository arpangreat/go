octicon
=======

[![Build Status](https://travis-ci.org/shurcooL/octicon.svg?branch=master)](https://travis-ci.org/shurcooL/octicon) [![GoDoc](https://godoc.org/github.com/shurcooL/octicon?status.svg)](https://godoc.org/github.com/shurcooL/octicon)

Package octicon provides GitHub Octicons.

Installation
------------

```bash
go get -u github.com/shurcooL/octicon
```

License
-------

-	[MIT License](https://opensource.org/licenses/mit-license.php)
