package models

func (ms *ModelSuite) Test_Widget() {
	ms.Fail("This test needs to be implemented!")
}
