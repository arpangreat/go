# Pop Stands on the Shoulders of Giants

Pop does not try to reinvent the wheel! Instead, it uses the already great wheels developed by the Go community and puts them all together in the best way possible. Without these giants, this project would not be possible. Please make sure to check them out and thank them for all of their hard work.

Thank you to the following **GIANTS**:


* [github.com/cockroachdb/apd](https://godoc.org/github.com/cockroachdb/apd)

* [github.com/cockroachdb/cockroach-go](https://godoc.org/github.com/cockroachdb/cockroach-go)

* [github.com/fatih/color](https://godoc.org/github.com/fatih/color)

* [github.com/go-sql-driver/mysql](https://godoc.org/github.com/go-sql-driver/mysql)

* [github.com/gobuffalo/attrs](https://godoc.org/github.com/gobuffalo/attrs)

* [github.com/gobuffalo/envy](https://godoc.org/github.com/gobuffalo/envy)

* [github.com/gobuffalo/fizz](https://godoc.org/github.com/gobuffalo/fizz)

* [github.com/gobuffalo/flect](https://godoc.org/github.com/gobuffalo/flect)

* [github.com/gobuffalo/genny](https://godoc.org/github.com/gobuffalo/genny)

* [github.com/gobuffalo/gogen](https://godoc.org/github.com/gobuffalo/gogen)

* [github.com/gobuffalo/logger](https://godoc.org/github.com/gobuffalo/logger)

* [github.com/gobuffalo/nulls](https://godoc.org/github.com/gobuffalo/nulls)

* [github.com/gobuffalo/packd](https://godoc.org/github.com/gobuffalo/packd)

* [github.com/gobuffalo/packr/v2](https://godoc.org/github.com/gobuffalo/packr/v2)

* [github.com/gobuffalo/plush](https://godoc.org/github.com/gobuffalo/plush)

* [github.com/gobuffalo/validate](https://godoc.org/github.com/gobuffalo/validate)

* [github.com/gofrs/uuid](https://godoc.org/github.com/gofrs/uuid)

* [github.com/jackc/fake](https://godoc.org/github.com/jackc/fake)

* [github.com/jackc/pgx](https://godoc.org/github.com/jackc/pgx)

* [github.com/jmoiron/sqlx](https://godoc.org/github.com/jmoiron/sqlx)

* [github.com/lib/pq](https://godoc.org/github.com/lib/pq)

* [github.com/jackc/pgx](https://godoc.org/github.com/jackc/pgx)

* [github.com/mattn/go-colorable](https://godoc.org/github.com/mattn/go-colorable)

* [github.com/mattn/go-isatty](https://godoc.org/github.com/mattn/go-isatty)

* [github.com/mattn/go-sqlite3](https://godoc.org/github.com/mattn/go-sqlite3)

* [github.com/pkg/errors](https://godoc.org/github.com/pkg/errors)

* [github.com/satori/go.uuid](https://godoc.org/github.com/satori/go.uuid)

* [github.com/shopspring/decimal](https://godoc.org/github.com/shopspring/decimal)

* [github.com/spf13/cobra](https://godoc.org/github.com/spf13/cobra)

* [github.com/stretchr/testify](https://godoc.org/github.com/stretchr/testify)

* [golang.org/x/sync](https://godoc.org/golang.org/x/sync)

* [gopkg.in/yaml.v2](https://godoc.org/gopkg.in/yaml.v2)
