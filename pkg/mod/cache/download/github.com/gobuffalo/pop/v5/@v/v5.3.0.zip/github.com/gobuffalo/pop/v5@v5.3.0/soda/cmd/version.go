package cmd

// Version defines the current Pop version.
const Version = "v5.3.0"
