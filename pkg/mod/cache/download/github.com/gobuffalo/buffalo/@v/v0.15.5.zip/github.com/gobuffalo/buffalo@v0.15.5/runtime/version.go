package runtime

// Version is the current version of the buffalo binary
var Version = "v0.15.5"
