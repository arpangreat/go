package syncx

// Version of syncx
const Version = "v0.0.1"
