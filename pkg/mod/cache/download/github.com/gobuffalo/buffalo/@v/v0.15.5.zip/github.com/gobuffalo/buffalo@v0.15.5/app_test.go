package buffalo

func voidHandler(c Context) error {
	return nil
}
