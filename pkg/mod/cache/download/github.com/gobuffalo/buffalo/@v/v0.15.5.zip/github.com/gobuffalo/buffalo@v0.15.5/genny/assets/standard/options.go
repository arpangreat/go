package standard

// Options for generating a new standard set of assets
type Options struct{}
