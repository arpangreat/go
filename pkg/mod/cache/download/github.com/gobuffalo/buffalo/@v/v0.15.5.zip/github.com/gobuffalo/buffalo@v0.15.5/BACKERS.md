# Financial Backers of the Buffalo Project

Buffalo is a community-driven project that is run by individuals who believe that Buffalo is the way to quickly, and easily, build high quality, scalable applications in Go.

Financial contributions to the Buffalo go towards ongoing development costs, servers, swag, conferences, etc...

If you, or your company, use Buffalo, please consider supporting this effort to make rapid web development in Go, simple, easy, and fun!

[http://patreon.com/buffalo](http://patreon.com/buffalo)

---

## Platinum Sponsors

* **[Gopher Guides](https://www.gopherguides.com)**
* **[PaperCall.io](https://www.papercall.io)**
* [Your Company Here](http://patreon.com/buffalo)

### Gold Sponsors

* [Your Company Here](http://patreon.com/buffalo)

### Premium Backers

* [Your Company Here](http://patreon.com/buffalo)

#### Generous Backers

* **[Zhorty](https://zhorty.com)**
* [Your Company Here](http://patreon.com/buffalo)

