package plugdeps

var pop = Plugin{
	Binary: "buffalo-pop",
	GoGet:  "github.com/gobuffalo/buffalo-pop",
}
