package main

import (
	"github.com/gobuffalo/buffalo/buffalo/cmd"
)

func main() {
	cmd.Execute()
}
