package packr

import "github.com/gobuffalo/packd"

type File = packd.File
