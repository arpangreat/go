package builder

type pkg struct {
	Name  string
	Dir   string
	Boxes []box
}
