package packr

const Version = "v1.25.0"
