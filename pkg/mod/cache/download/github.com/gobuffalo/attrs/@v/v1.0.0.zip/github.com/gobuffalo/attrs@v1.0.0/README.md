# attrs

[![](https://github.com/gobuffalo/attrs/workflows/Tests/badge.svg)](https://github.com/gobuffalo/attrs/actions)
[![GoDoc](https://godoc.org/github.com/gobuffalo/attrs?status.svg)](https://godoc.org/github.com/gobuffalo/attrs)

### Requirements

* Go 1.13+
* Go Modules

### Installation

```bash
$ go get github.com/gobuffalo/attrs/cmd/attrs
```

---
