# github.com/gobuffalo/attrs Stands on the Shoulders of Giants

github.com/gobuffalo/attrs does not try to reinvent the wheel! Instead, it uses the already great wheels developed by the Go community and puts them all together in the best way possible. Without these giants, this project would not be possible. Please make sure to check them out and thank them for all of their hard work.

Thank you to the following **GIANTS**:


* [github.com/gobuffalo/flect](https://godoc.org/github.com/gobuffalo/flect)

* [github.com/pkg/errors](https://godoc.org/github.com/pkg/errors)

* [github.com/stretchr/testify](https://godoc.org/github.com/stretchr/testify)
