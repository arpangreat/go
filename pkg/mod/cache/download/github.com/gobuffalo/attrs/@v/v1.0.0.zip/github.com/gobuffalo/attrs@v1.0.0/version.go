package attrs

// Version of attrs
const Version = "v0.1.0"
