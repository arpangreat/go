package validate

// Version of validate
const Version = "v0.0.1"
