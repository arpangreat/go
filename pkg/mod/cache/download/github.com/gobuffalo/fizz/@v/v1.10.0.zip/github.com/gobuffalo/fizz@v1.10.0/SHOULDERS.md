# Fizz Stands on the Shoulders of Giants

Fizz does not try to reinvent the wheel! Instead, it uses the already great wheels developed by the Go community and puts them all together in the best way possible. Without these giants, this project would not be possible. Please make sure to check them out and thank them for all of their hard work.

Thank you to the following **GIANTS**:


* [github.com/blang/semver](https://godoc.org/github.com/blang/semver)

* [github.com/fatih/structs](https://godoc.org/github.com/fatih/structs)

* [github.com/go-sql-driver/mysql](https://godoc.org/github.com/go-sql-driver/mysql)

* [github.com/gobuffalo/envy](https://godoc.org/github.com/gobuffalo/envy)

* [github.com/gobuffalo/flect](https://godoc.org/github.com/gobuffalo/flect)

* [github.com/gobuffalo/github_flavored_markdown](https://godoc.org/github.com/gobuffalo/github_flavored_markdown)

* [github.com/gobuffalo/plush](https://godoc.org/github.com/gobuffalo/plush)

* [github.com/gobuffalo/tags](https://godoc.org/github.com/gobuffalo/tags)

* [github.com/gobuffalo/uuid](https://godoc.org/github.com/gobuffalo/uuid)

* [github.com/gobuffalo/validate](https://godoc.org/github.com/gobuffalo/validate)

* [github.com/gofrs/uuid](https://godoc.org/github.com/gofrs/uuid)

* [github.com/kballard/go-shellquote](https://godoc.org/github.com/kballard/go-shellquote)

* [github.com/markbates/inflect](https://godoc.org/github.com/markbates/inflect)

* [github.com/microcosm-cc/bluemonday](https://godoc.org/github.com/microcosm-cc/bluemonday)

* [github.com/onsi/ginkgo](https://godoc.org/github.com/onsi/ginkgo)

* [github.com/onsi/gomega](https://godoc.org/github.com/onsi/gomega)

* [github.com/pkg/errors](https://godoc.org/github.com/pkg/errors)

* [github.com/rogpeppe/go-internal](https://godoc.org/github.com/rogpeppe/go-internal)

* [github.com/serenize/snaker](https://godoc.org/github.com/serenize/snaker)

* [github.com/stretchr/testify](https://godoc.org/github.com/stretchr/testify)

* [golang.org/x/net](https://godoc.org/golang.org/x/net)

* [golang.org/x/sync](https://godoc.org/golang.org/x/sync)

* [golang.org/x/sys](https://godoc.org/golang.org/x/sys)

* [golang.org/x/text](https://godoc.org/golang.org/x/text)

* [google.golang.org/appengine](https://godoc.org/google.golang.org/appengine)

* [gopkg.in/yaml.v2](https://godoc.org/gopkg.in/yaml.v2)
