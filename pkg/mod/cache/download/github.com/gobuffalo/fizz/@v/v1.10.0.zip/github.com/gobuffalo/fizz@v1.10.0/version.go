package fizz

// Version gives the current fizz version.
const Version = "v1.9.5"
