package pop

// Version is the current pop version (not the buffalo-pop one).
const Version = "v5.1.1"
