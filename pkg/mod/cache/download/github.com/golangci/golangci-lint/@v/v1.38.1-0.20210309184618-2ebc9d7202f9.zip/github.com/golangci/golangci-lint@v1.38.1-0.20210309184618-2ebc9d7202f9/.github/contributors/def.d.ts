declare module "name-your-contributors"

declare module "@octokit/graphql"
