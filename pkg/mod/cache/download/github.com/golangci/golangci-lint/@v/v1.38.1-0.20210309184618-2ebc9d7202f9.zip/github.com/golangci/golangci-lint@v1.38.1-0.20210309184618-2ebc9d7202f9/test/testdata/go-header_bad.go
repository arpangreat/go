/*MY TITLE!*/ // ERROR `Expected:TITLE\., Actual: TITLE!`

//args: -Egoheader
//config_path: testdata/configs/go-header.yml
package testdata
