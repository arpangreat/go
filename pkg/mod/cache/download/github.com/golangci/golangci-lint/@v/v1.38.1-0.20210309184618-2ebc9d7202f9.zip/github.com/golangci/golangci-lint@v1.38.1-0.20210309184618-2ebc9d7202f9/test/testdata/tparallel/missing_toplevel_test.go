package testdata

import (
	"testing"
)

func TestTopLevel(t *testing.T) {
	t.Run("", func(t *testing.T) {
		t.Parallel()
	})
}
