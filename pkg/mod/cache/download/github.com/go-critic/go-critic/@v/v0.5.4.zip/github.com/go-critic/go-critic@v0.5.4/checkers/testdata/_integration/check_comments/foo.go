package foo

import (
	"errors"
	//"os"
	/*
		"fmt"
		"strconv"
	*/)

import (
	// "foo/bar"
	// "foo/bar/baz"
	_ "errors"
)

// import "errors"

var _ = errors.New
