package b

import "time"

const (
	SomeInt      = 10
	SomeDuration = 1 * time.Second
)
