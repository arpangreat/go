package main

import "github.com/kevinschoon/pomo/pkg/cmd"

func main() {
    cmd.Run()
}
