package pomo

var Version = "undefined"
