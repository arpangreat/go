# Funlen linter

Funlen is a linter that checks for long functions. It can checks both on the number of lines and the number of statements.

The default limits are 60 lines and 40 statements. You can configure these.

## Installation guide

Funlen is included in [golangci-lint](https://github.com/golangci/golangci-lint/). Install it and enable funlen.
