// Cyclop calculates cyclomatic complexities of functions in Go source code.
// Simple usage:
//
//     cyclop .
//
// Read more about usage in https://github.com/bkielbasa/cyclop/blob/master/README.md
package main
