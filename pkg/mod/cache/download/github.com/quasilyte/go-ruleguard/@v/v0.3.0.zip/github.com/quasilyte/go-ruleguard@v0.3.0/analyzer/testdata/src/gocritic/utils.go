package gocritic

func makeSlice() []int {
	return []int{}
}

func makeArray() [200]int {
	return [200]int{}
}
