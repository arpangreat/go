package a

import "database/sql"

var db *sql.DB
