package foo

func Bar() {
	make = 3
}

func (m *M) error() {}

type S struct {
	int
}
