//predeclared -ignore new,int

package foo

func new() {}

var int = 10

func copy() {}
