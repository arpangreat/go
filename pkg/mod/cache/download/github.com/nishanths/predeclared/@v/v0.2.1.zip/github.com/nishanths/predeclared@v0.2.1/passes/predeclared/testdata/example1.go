//predeclared -q

package print

func append(s int) {
	copy := s
	x.Push(copy)
}

type F interface {
	new() T
}

func (p Pool) new() T {}
