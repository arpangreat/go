package calc

import "github.com/nishanths/exhaustive/testdata/playground/token"

func processToken(t token.Token) {
	switch t {
	case token.Add:
		// ...
	case token.Subtract:
		// ...
	case token.Multiply:
		// ...
	}
}
