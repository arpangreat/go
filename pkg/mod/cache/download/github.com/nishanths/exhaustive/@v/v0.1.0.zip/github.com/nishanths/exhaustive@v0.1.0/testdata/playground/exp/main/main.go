package main

// import "github.com/nishanths/exhaustive/testdata/playground/exp"

func main() {
}
