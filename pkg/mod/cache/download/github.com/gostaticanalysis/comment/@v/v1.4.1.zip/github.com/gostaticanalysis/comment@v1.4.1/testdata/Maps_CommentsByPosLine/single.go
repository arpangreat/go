-- a.go --
package a

// a
func A_() {}

// b
func B() {}
