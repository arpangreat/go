# gostaticanalysis/comment

[![godoc.org][godoc-badge]][godoc]

`comment` provides utilities for [ast.CommentMap](https://golang.org/pkg/go/ast/#CommentMap).

<!-- links -->
[godoc]: https://godoc.org/github.com/gostaticanalysis/comment
[godoc-badge]: https://img.shields.io/badge/godoc-reference-4F73B3.svg?style=flat-square&label=%20godoc.org

