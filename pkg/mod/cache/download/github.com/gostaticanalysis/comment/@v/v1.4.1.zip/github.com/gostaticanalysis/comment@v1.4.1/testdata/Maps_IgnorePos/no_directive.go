-- a.go --
package a

// test-check reason
func A_() {}
