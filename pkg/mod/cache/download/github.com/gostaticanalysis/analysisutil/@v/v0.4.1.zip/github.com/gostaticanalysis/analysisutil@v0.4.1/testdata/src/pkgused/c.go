package pkgused

import (
	"log"
)

func F2() {
	log.Println("c")
}
