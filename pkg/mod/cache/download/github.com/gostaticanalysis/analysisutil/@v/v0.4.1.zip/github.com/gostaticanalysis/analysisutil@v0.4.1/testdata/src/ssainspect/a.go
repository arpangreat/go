package a

var v int

func f1() {
	if v == 0 {
		println("hoge")
	}

	for i := 0; i <= 10; i++ {
		println("hoge")
	}
}
