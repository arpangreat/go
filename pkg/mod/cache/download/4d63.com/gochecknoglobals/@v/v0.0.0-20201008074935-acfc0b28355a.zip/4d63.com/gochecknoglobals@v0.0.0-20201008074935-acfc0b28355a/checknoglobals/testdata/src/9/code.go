package code

var Version string   // want "Version is a global variable"
var version22 string // want "version22 is a global variable"
var version string
